@extends('errors::minimal')

@section('title', translate('Unauthorized'))
@section('code', '401')
@section('message', translate('Unauthorized'))
